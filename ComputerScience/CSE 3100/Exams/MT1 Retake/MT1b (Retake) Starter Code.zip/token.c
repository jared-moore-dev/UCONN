#include "token.h"
#include <ctype.h>
#include <stdio.h>

int readToken(Token* t) {
/* Q3.1 Implement the read Token function 
    * TODO parse the token t to assign values to t->type and t->value fields
    * return a boolean value to indicate EOF */
   return 1; /* fix me */
}
