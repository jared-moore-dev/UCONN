#include <stdio.h>

/* Q1. Implement the functions getMSDigit() and main() */

int getMSDigit(int x)
{
   // TODO: extract the leading digit of integer x and return it
   return 0; /* fix me */
}

int main()
{
   /* TODO: read input from the stdin
    * for each integer, obtain the leading digit
    * calculate the frequencies of the leading digits
    * print the frequencies on stdout */
    return 0;
}
