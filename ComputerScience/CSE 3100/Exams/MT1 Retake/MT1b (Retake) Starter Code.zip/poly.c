#include <stdio.h>
#include <stdlib.h>

char* readString() {
   int   l = 1; // start with enough space to hold the emtpy string.
   char* s = malloc(l * sizeof(char));
   int i = 0;
   char ch;
   while ((ch = getchar()) != '\n') {
      if (i == l-1) {
         s = realloc(s,l*2*sizeof(char));
         l *= 2;
      }
      s[i++] = ch;
   }
   s[i] = 0;
   return s;
}

unsigned long hashString(char* s) {
   /* Q2. Implement the hashString function
    * TODO compute the hash of the input string s
    * return the hash value */
   return 1; /* fix me */
}

int main() {
   char buf[512];
   char* str = readString();
   printf("Hash of [%s] is %lu\n",str,hashString(str));
   free(str);
   return 0;
}
