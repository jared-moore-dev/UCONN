#include "stack.h"
#include <stdio.h>
#include <stdlib.h>
#include "token.h"

int main() {
   /* Q3.2 Implement the RPN calculator in the main() function
    * TODO read tokens from the stdin till the user inputs EOF or the quit command
    * use the given stack implementation to evaluate the expression as tokens are read */
   return 0;
}

