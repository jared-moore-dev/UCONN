#ifndef __SUBSETSUM_H
#define __SUBSETSUM_H

void subSetSum(int n,int s,int t[n]);

#endif
