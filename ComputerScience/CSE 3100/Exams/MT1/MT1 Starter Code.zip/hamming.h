#ifndef __HAMMING_H
#define __HAMMING_H

/* Do not modify this file */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* readString();
int computeHD(char* s1,char* s2);

#endif
