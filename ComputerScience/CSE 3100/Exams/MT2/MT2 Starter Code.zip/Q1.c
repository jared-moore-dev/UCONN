#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

#define READEND 0
#define WRITEEND 1

int main(int argc,char* argv[])
{
   /* TODO: Q1
      Implement "ls /dev | xargs | cut -d ' ' -f<a>-<b>" 
      where <a> and <b> are from the command line
      The use of system is prohibited.
   */
   return 0;
}


