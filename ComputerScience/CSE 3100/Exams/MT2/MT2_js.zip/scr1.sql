.import demo.csv contact
.schema
select * from contact;
.quit
