#ifndef __UPPER_H
#define __UPPER_H

char* strupper(char* s);

#endif
