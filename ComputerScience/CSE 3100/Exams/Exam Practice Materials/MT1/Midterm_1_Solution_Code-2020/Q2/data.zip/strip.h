#ifndef __STRIP_H
#define __STRIP_H

char* strip(char* s);

#endif
