#include <stdio.h>

int main(int argc, char* argv[]){
  printf("Please enter n, e and m: ");
  int n, e, m;
  e = 0;
  if(/* TODO: Read integers into n, e and m. Check the manpages to see what scanf returns. */){
    /* TODO: Implement the pseudocode to do the modular exponentiation, and then printf it */
  }else{
    printf("You did not enter three integers. Exiting\n");
  }
}
