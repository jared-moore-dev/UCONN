#include <stdio.h>

int main(int argc, char* argv[]){
  printf("n = ");
  int n;
  /*TODO: Read in n from the user */
  unsigned int denom = 1;
  double e = 1;
  for(int i = 1; i <= n; i++){
    /* TODO: Update denom, update the sum */
  }
  printf("e =  %lf\n", e);
}
