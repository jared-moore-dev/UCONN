#include <stdio.h>
#include <math.h>
int main(int argc, char* argv[]){
  double x, min = INFINITY, max = -INFINITY;
  int i = 0;
  while(scanf("%lf", &x) == 1){
    /* TODO: Compute the min and max, and printf them */
  }
}
