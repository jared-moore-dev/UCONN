public class PatientNotFoundException extends Exception {
    public PatientNotFoundException (String errorMessage) {
        super(errorMessage);
    }
}
